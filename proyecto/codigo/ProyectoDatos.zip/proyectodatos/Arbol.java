package proyectodatos;

import java.util.TreeMap;
/**
 *
 * @author Usuario
 */
public class Arbol {
    static TreeMap<String,TreeMap<String,Archivo>> raiz = new TreeMap<>();
    
    public static void main (String [] args){
        Archivo a1= new Archivo("Data", "C/Data");
        Archivo a2= new Archivo("Data", "C/Examenes/Data");
        agregar(a1);
        agregar(a2);
        buscarPorNombre("Data");
    }
    public static void agregar (Archivo a){
        if (raiz.get(a.getNombre())==null){
            System.out.println("No hay");
            TreeMap<String, Archivo> a2 = new TreeMap<>();
            a2.put(a.getNombre(), a);
            raiz.put(a.getNombre(),a2);
        }else{
            System.out.println("Existe");
            raiz.get(a.getNombre()).put(a.getRuta(), a);
        }
    }
    
    public static void buscarPorNombre (String nombre){
        TreeMap t= raiz.get(nombre);
        if (t == null){
            System.out.println("No existe");
        }else{
            if (t.size()==1){
                System.out.println("Existe");
                Archivo a= (Archivo) t.firstEntry().getValue();
                System.out.println(a.getRuta());
            }else{
                System.out.println("Hay mas de un archivo con ese nombre");
                Object [] list= t.values().toArray();
                for (int i=0; i<list.length; i++){
                    System.out.println(((Archivo)list[i]).getRuta());
                }
            }
        }
    }
    
    public static void buscarPorAutor (String autor) {
        
    }
    
}
