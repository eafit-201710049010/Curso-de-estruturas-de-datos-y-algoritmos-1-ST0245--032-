package proyectodatos;

/**
 *
 * @author Alejandro Arroyave Bedoya
 */
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Stack;

public class ProyectoDatos {

    public static void main(String[] args) throws IOException {
        try {
            leerArchivo("C:\\Users\\Usuario\\Desktop\\archivo.txt");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void leerArchivo(String archivo)
    throws FileNotFoundException, IOException {
        String cadena;
        int profundidad = 4;
        FileInputStream entrada = new FileInputStream(new File(archivo));
        InputStreamReader file = new InputStreamReader(entrada, "Unicode");
        BufferedReader br = new BufferedReader(file);
        String ruta = br.readLine();
        String si = ruta;
        while ((cadena = br.readLine()) != null) {

            while (true) {
                if (ruta.equals(si)){
                    ruta = ruta + getNombre(cadena);
                    break;
                }else{
                    if (cadena.indexOf("[") == profundidad) {
                        ruta=desconcatenar(ruta);
                        ruta = ruta + getNombre(cadena);
                        break;
                    } else {
                        if (cadena.indexOf("[") > profundidad) {
                            profundidad += 2;
                            ruta = ruta + getNombre(cadena);
                            break;
                        } else {
                            profundidad -= 2;
                            ruta=desconcatenar(ruta);
                        }
                    }
                }
            }
            ruta= ruta + '/';
            System.out.println(ruta);
        }

        br.close();
    }

    public static String getNombre(String archivo)
    throws FileNotFoundException, IOException {
        Stack nombreInverso = new Stack();
        for (int i = archivo.length() - 1; i >= 0; i--) {
            if (archivo.charAt(i - 1) == ']') {
                break;
            }
            nombreInverso.push(archivo.charAt(i));
        }
        String cadena = "";
        while (!nombreInverso.empty()) {
            cadena = cadena + nombreInverso.pop();
        }
        return cadena;
    }

    public static String desconcatenar(String ruta) {
        ruta = ruta.substring(0, ruta.length() - 1);
        int tamaño = ruta.length();
        for (int i = ruta.length()-1; i > 0; i--) {
            tamaño--;
            if (ruta.charAt(i) == '/') {
                break;
            }
        }
        ruta= ruta.substring(0, tamaño) + '/';
        return ruta;
    }
}