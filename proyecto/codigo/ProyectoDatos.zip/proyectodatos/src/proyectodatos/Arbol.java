package proyectodatos;

import java.util.TreeMap;
/**
 * Esta es la estructura de datos, básicamente, es basada en un árbol rojo-negro
 * que por dentro tiene otro árbol rojo-negro.
 * @author Alejandro Arroyave Bedoya y Johanna Saraí Caicedo Mejía
 */
public class Arbol {
    /**
     * Es un mapa basado en un árbol rojo-negro. Aquí se guardaran los datos.
     */
    private static TreeMap<String,TreeMap<String,Archivo>> raiz;

    /**
     * Constructor de la clase Arbol.
     */
    public Arbol() {
        this.raiz = new TreeMap<>();
    }
    
    /**
     * Se utiliza para agregar los elementos a la estructura de datos.
     * @param a Es el archivo a ingresar.
     */
    public void agregar (Archivo a){
        if (raiz.get(a.getNombre())==null){
            TreeMap<String, Archivo> a2 = new TreeMap<>();
            a2.put(a.getNombre(), a);
            raiz.put(a.getNombre(),a2);
        }else{
            raiz.get(a.getNombre()).put(a.getRuta(), a);
        }
    }
    /**
     * Tiene como funcionalidad buscar un elemento del árbol por su nombre.
     * @param nombre Nombre a buscar.
     */
    public static void buscarPorNombre (String nombre){
        TreeMap t= raiz.get(nombre);
        if (t == null){
            System.out.println("No existe");
        }else{
            if (t.size()==1){
                System.out.println("Existe");
                Archivo a= (Archivo) t.firstEntry().getValue();
                System.out.println(a.getRuta());
            }else{
                System.out.println("Hay mas de un archivo con ese nombre");
                Object [] list= t.values().toArray();
                for (int i=0; i<list.length; i++){
                    System.out.println(((Archivo)list[i]).getRuta());
                }
            }
        }
    }
}
