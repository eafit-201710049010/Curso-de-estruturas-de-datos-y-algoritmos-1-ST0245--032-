package proyectodatos;

/**
 * @description La clase principal del proyecto
 * @author Alejandro Arroyave Bedoya y Johanna Saraí Caicedo Mejía
 * @version 10-2017
 */
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Stack;

public class ProyectoDatos {

    /**
     * Instancia de la estructura de datos
     */

    static Arbol arbol = new Arbol();

    /**
     * Es el método principal de la clase
     *
     * @param args parametro predeterminado para el método principal
     */
    public static void main(String[] args) {
        try {
            leerArchivo("C:\\Users\\Usuario\\Desktop\\archivo.txt");
            arbol.buscarPorNombre("fly.eps");
        } catch (IOException e) {
        }
    }

    /**
     * Este método lee el archivo, procesa y encuentra la ruta, y por último,
     * con el nombre y la ruta del archivo, crea un objeto de tipo archivo y lo
     * introduce a la estructura de datos
     *
     * @param archivo Es la ruta para llegar a la ubicación del archivo
     * @throws FileNotFoundException Se lanza cuando no encuentra el documento
     * @throws IOException Se lanza cuando hay un problema de entrada en el
     * archivo
     */
    public static void leerArchivo(String archivo)
            throws FileNotFoundException, IOException {
        String cadena;
        int profundidad = 4;
        FileInputStream entrada = new FileInputStream(new File(archivo));
        InputStreamReader file = new InputStreamReader(entrada, "Unicode");
        BufferedReader br = new BufferedReader(file);
        String ruta = br.readLine();
        String si = ruta;
        while ((cadena = br.readLine()) != null) {

            while (true) {
                if (ruta.equals(si)) {
                    ruta = ruta + getNombre(cadena);
                    break;
                } else {
                    if (cadena.indexOf("[") == profundidad) {
                        ruta = desconcatenar(ruta);
                        ruta = ruta + getNombre(cadena);
                        break;
                    } else {
                        if (cadena.indexOf("[") > profundidad) {
                            profundidad += 2;
                            ruta = ruta + getNombre(cadena);
                            break;
                        } else {
                            profundidad -= 2;
                            ruta = desconcatenar(ruta);
                        }
                    }
                }
            }
            ruta = ruta + '/';
            arbol.agregar(new Archivo(getNombre(cadena), ruta));
        }

        br.close();
    }

    /**
     * Retorna el nombre del archivo que se le pase
     *
     * @param archivo Es la ruta del archivo a extraer el nombre
     * @return El nombre del archivo
     */
    public static String getNombre(String archivo) {
        Stack nombreInverso = new Stack();
        for (int i = archivo.length() - 1; i >= 0; i--) {
            if (archivo.charAt(i - 1) == ']') {
                break;
            }
            nombreInverso.push(archivo.charAt(i));
        }
        String cadena = "";
        while (!nombreInverso.empty()) {
            cadena = cadena + nombreInverso.pop();
        }
        return cadena;
    }

    /**
     * Se utiliza para bajar de monarquía en el sistema de archivos, pues lo que
     * hace es quitar la última cadena de caracteres hasta encontrar un '/'
     *
     * @param ruta Es la ruta que va a subir una carpeta
     * @return La ruta de la carpeta padre de la introducida.
     */
    private static String desconcatenar(String ruta) {
        ruta = ruta.substring(0, ruta.length() - 1);
        int tamaño = ruta.length();
        for (int i = ruta.length() - 1; i > 0; i--) {
            tamaño--;
            if (ruta.charAt(i) == '/') {
                break;
            }
        }
        ruta = ruta.substring(0, tamaño) + '/';
        return ruta;
    }
}
