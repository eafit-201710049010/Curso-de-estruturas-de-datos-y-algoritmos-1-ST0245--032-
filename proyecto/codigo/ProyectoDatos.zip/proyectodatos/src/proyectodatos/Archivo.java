/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyectodatos;

/**
 * @description Esta es la clase archivo, son los ojetos que se van a guardar en
 * la estructura de datos
 * @author Alejando Arroyave Bedoya y Johanna Caicedo Mejía
 */
public class Archivo {

    /**
     * Es la ruta del archivo.
     */
    private final String ruta;
    /**
     * Nombre del archivo, que también servirá como clave para guardarlo en el
     * árbol.
     */
    private final String nombre;

    /**
     * Constructor de la clase Archivo
     *
     * @param nombre Asigna nombre a un archivo.
     * @param ruta Asigna ruta a un archivo.
     */
    public Archivo(String nombre, String ruta) {
        this.nombre = nombre;
        this.ruta = ruta;
    }

    /**
     * Es el método para devolver el nombre del archivo.
     *
     * @return Nombre del archivo.
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * Es el método que devuelve la ruta del archivo.
     *
     * @return Ruta del archivo.
     */
    public String getRuta() {
        return ruta;
    }
}
