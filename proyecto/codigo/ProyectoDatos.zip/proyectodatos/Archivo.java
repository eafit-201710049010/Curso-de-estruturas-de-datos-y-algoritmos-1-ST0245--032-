/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyectodatos;

/**
 *
 * @author Usuario
 */
public class Archivo {
    private String ruta;
    private String nombre;
    
    public Archivo (String nombre, String ruta){
        this.nombre=nombre;
        this.ruta=ruta;
    }
    
    public String getNombre (){
        return nombre;
    }
    
    public String getRuta (){
        return ruta;
    }
}
